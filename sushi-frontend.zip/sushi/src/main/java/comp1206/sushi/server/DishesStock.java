package comp1206.sushi.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.common.Staff;

public class DishesStock {
	static List <Dish> dishes = new CopyOnWriteArrayList<Dish>();
	//static List <Dish> dishes = Collections.synchronizedList(new ArrayList <Dish>());
	//static ArrayList <Dish> dishes = new ArrayList<Dish>();
	static int restockThreshold;
	static int restockAmount;
	static int stock;
	static int addedStock;
	static int i;
	
	public static void addDish(Dish dish){
		System.out.println(dish.getName());
		dishes.add(dish);	
		
	}
	
	public static Number restockDish(Dish dish) {
		System.out.println("all dishes  " + dishes);
				System.out.println("yoo hoooo" + dish.getName());
				
				
				stock = dish.getStock().intValue();
				restockThreshold = (int) dish.getRestockThreshold();
				restockAmount = (int) dish.getRestockAmount();
				
				System.out.println("$$$$$" + stock);
				System.out.println("$$$$$" + restockThreshold);
				System.out.println("$$$$$" + restockAmount);
				
				
				if(stock < restockThreshold) {
					while(stock < restockThreshold) {
						stock = stock + restockAmount;
						i++;
					}
				}
				else {
					i = 0;
				}
			
			
			dishes.remove(dish);
		
		
		return stock;
	}
	
	public static List<Dish> checkRestock() {
		return dishes;	
	}
	
	public static Number findAddedStock() {
		addedStock = i*restockAmount;
		i=0;
		System.out.println("Added stock is" + addedStock);
		return addedStock;
	}


	

	
	/*public void decreaseStock() {
		
	} */
	

	
}