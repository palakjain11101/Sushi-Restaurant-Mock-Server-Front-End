package comp1206.sushi.server;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import comp1206.sushi.common.DataPersistence;
import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Drone;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.common.Order;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.common.Restaurant;
import comp1206.sushi.common.Staff;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.common.User;

import java.io.*;
public class Configuration {
		Server server;
		BufferedReader reader;
		String line;
		Restaurant restaurant;
		List<Drone> dronesList;
		List<Postcode> postcodesList;
		List<Supplier> suppliersList;
		List<Ingredient> ingredientsList;
		List<Dish> dishesList;
		List<Order> ordersList;
		List<Staff> staffsList;
		List<User> users;

		public Configuration(String fileName, Server server) 	{
				this.server = server;
				dronesList  = server.getDrones();
				dronesList.clear();
				postcodesList  = server.getPostcodes();
				postcodesList.clear();
				suppliersList  = server.getSuppliers();
				suppliersList.clear();
				ingredientsList  = server.getIngredients();
				ingredientsList.clear();
				dishesList  = server.getDishes();
				dishesList.clear();
				ordersList = server.getOrders();
				ordersList.clear();
				staffsList = server.getStaff();
				staffsList.clear();
				users = server.getUsers();
				users.clear();
			try{
				reader = new BufferedReader(new FileReader(fileName));
				DataPersistence.createFile();
				getLine();
	    	}
			
			catch (FileNotFoundException fnf) {
				System.out.println("File not found !");
	
			}
		}
		
		
			
		public void getLine(){
			try{
				while ((line = reader.readLine()) != null) {
						String words[] = line.split(":"); 
						
						if(words[0].equals("POSTCODE")) {
							String postcodeName = words[1];
							server.addPostcode(postcodeName);
							//System.out.println("Postcodes are updated");
						}
					
						else if(words[0].equals("USER")) {
							for(Postcode postcode: postcodesList) {
								if(words[4].equals(postcode.getName())) {
									User user = new User(words[1], words[2], words[3], postcode);
									server.addUser(user);
									//System.out.println("Users are updated");
								}
							}
						}
						
						else if(words[0].equals("SUPPLIER")) {
							for(Postcode postcode: postcodesList) {
								if(words[2].equals(postcode.getName())) {
									server.addSupplier(words[1], postcode);
								}
							}

							//System.out.println("Suppliers are updated");
						}
						
						else if(words[0].equals("INGREDIENT")) {
							for(Supplier supplier: suppliersList) {
								if(words[3].equals(supplier.getName())) {
									server.addIngredient(words[1], words[2], supplier, Integer.parseInt(words[4]), Integer.parseInt(words[5]), Integer.parseInt(words[6]));
									//restockIngredient();
								}
							}

							//System.out.println("Suppliers are updated");
						}
						
						else if(words[0].equals("STOCK")) {
							for(Ingredient ingredient: ingredientsList) {
								if(words[1].equals(ingredient.getName())) {
									//System.out.println("dish set stock in config:"+ dish.getName() +words[2]);
									//System.out.println("--------------"+words[2]);
									server.setStock(ingredient, Integer.parseInt(words[2]));
									Map<Ingredient, Number> map = new HashMap<Ingredient, Number>();
									map = server.getIngredientStockLevels();
									//System.out.println("-------" + map.get(ingredient));
									
									
								}
							}
							for(Dish dish: dishesList) {
								if(words[1].equals(dish.getName())) {
									//System.out.println("dish set stock in config:"+ dish.getName() +words[2]);
									server.setStock(dish, Integer.parseInt(words[2]));
								}
							}

							//System.out.println("Stock is updated");
						}
						
						else if(words[0].equals("STAFF")) {
							server.addStaff(words[1]);
						}
						
						else if(words[0].equals("DRONE")) {
							server.addDrone(Integer.parseInt(words[1]));
						}
						
						else if(words[0].equals("RESTAURANT")) {
							String restaurantName = words[1];
							String restaurantPostcode = words[2];
							//restaurant.setName(restaurantName);
							for(Postcode postcode: postcodesList ) {
								if(restaurantPostcode.equals(postcode.getName())) {
									restaurant = new Restaurant(restaurantName, postcode);
									DataPersistence.writeToFile("RESTAURANT:" + restaurant.getLocation());
									//restaurant.setLocation(postcode);
								}
							}
						}
						
						else if(words[0].equals("DISH")) {
							String recipe = words[6];
							
							Dish thisDish = server.addDish(words[1], words[2], Integer.parseInt(words[3]), Integer.parseInt(words[4]), Integer.parseInt(words[5]));
							
							String recipeLine[] = recipe.split(","); 
							for (int i = 0; i < recipeLine.length; i++) {
								String recipeLine2 = recipeLine[i];
								String recipeLine3[] = recipeLine2.split(" * ");
								Number quantity = Integer.parseInt(recipeLine3[0]);
								String item = recipeLine3[1];
								for(Ingredient ingredient: ingredientsList) {
									if(item.equals(ingredient.getName())) {
										server.addIngredientToDish(thisDish, ingredient, quantity);
									}
								}
								
							}
							server.notifyUpdate();
						}
						
						else if(words[0].equals("ORDER")) {
							Order order = new Order();
							String userName = words[1];
							String orderLine = words[2];
							String orderLine1[] = orderLine.split(",");
							for(int i=0; i < orderLine1.length; i++) {
								String orderLine2[] = orderLine.split(" * ");
								Number quantity = Integer.parseInt(orderLine2[0]);
								String dishName = orderLine2[1];
								
								order.setName(userName);
							}
							ordersList.add(order);
						}
				}
			}

			catch (IOException e) {
				e.printStackTrace();
			}
			

		}
			
}

