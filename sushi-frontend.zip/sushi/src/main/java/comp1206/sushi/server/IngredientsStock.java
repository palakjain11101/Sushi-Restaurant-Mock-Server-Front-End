package comp1206.sushi.server;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.common.Staff;

public class IngredientsStock {
	static List <Ingredient> ingredients = new CopyOnWriteArrayList<Ingredient>();
	//static List <Dish> dishes = Collections.synchronizedList(new ArrayList <Dish>());
	//static ArrayList <Dish> dishes = new ArrayList<Dish>();
	static int restockThreshold;
	static int restockAmount;
	static int stock;
	static int addedStock;
	static int i;
	
	public static void addIngredient(Ingredient ingredient){
		System.out.println(ingredient.getName());
		ingredients.add(ingredient);
		
		
	}
	
	public static Number restockIngredient(Ingredient ingredient) {
		System.out.println("all ingredients  " + ingredients);
				System.out.println("yoo hoooo" + ingredient.getName());
				
				
				stock = ingredient.getStock().intValue();
				restockThreshold = (int) ingredient.getRestockThreshold();
				restockAmount = (int) ingredient.getRestockAmount();
				
				System.out.println("$$$$$" + stock);
				System.out.println("$$$$$" + restockThreshold);
				System.out.println("$$$$$" + restockAmount);
				
				
				if(stock < restockThreshold) {
					while(stock < restockThreshold) {
						stock = stock + restockAmount;
						i++;
					}
				}
				else {
					i = 0;
				}
			
			
			ingredients.remove(ingredient);
		
		
		return stock;
	}
	
	public static List<Ingredient> checkRestock() {
		return ingredients;	
	}
	
	public static Number findAddedStock() {
		addedStock = i*restockAmount;
		i=0;
		System.out.println("Added stock is" + addedStock);
		return addedStock;
	}
	/*public void decreaseStock() {
		
	} */
	

	
}