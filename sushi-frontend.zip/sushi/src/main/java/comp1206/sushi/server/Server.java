package comp1206.sushi.server;

import java.io.File;
import java.io.IOException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import comp1206.sushi.client.Client;
import comp1206.sushi.common.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.locks.Lock;

import javax.swing.JOptionPane;

import comp1206.sushi.common.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
 
public class Server implements ServerInterface {

    private static final Logger logger = LogManager.getLogger("Server");
    
    
	//private static final Server Server = null;
	Client client;
	ServerComms serverComms;
	public Restaurant restaurant;
	public ArrayList<Dish> dishes = new ArrayList<Dish>();
	public ArrayList<Drone> drones = new ArrayList<Drone>();
	public ArrayList<Ingredient> ingredients = new ArrayList<Ingredient>();
	public List<Order> orders = new ArrayList<Order>();
	public ArrayList<Staff> staff = new ArrayList<Staff>();
	public ArrayList<Supplier> suppliers = new ArrayList<Supplier>();
	public ArrayList<User> users = new ArrayList<User>();
	public ArrayList<Postcode> postcodes = new ArrayList<Postcode>();
	private ArrayList<UpdateListener> listeners = new ArrayList<UpdateListener>();
	HashMap<Dish, Number> levels = new HashMap<Dish, Number>();
	HashMap<Ingredient, Number> levels1 = new HashMap<Ingredient, Number>();
	HashMap<Ingredient, Number> recipe = new HashMap<Ingredient, Number>();
	Map<Ingredient, Number> recipeforDish1 = new HashMap<Ingredient, Number>();
	Map<Ingredient, Number> recipeforDish2 = new HashMap<Ingredient, Number>();
	Map<Ingredient, Number> recipeforDish3 = new HashMap<Ingredient, Number>();

	private Object staffLock;
	private Object droneLock;
	

	
	
	public Server() {
        logger.info("Starting up server...");
        //Server1.startServer();
        
        File f = new File("newserver.txt");
        if(f.exists()) { 
            loadConfiguration("newserver.txt");
        }
        
        this.staffLock = new Object();
        this.droneLock = new Object();
		
        serverComms = new ServerComms(this);
        Thread thread = new Thread(serverComms);
        thread.start();
        
		Postcode restaurantPostcode = new Postcode("SO17 1BJ");
		restaurant = new Restaurant("Mock Restaurant",restaurantPostcode);
		//ingredientStock = new IngredientStock();
		DataPersistence.writeToFile("RESTAURANT" + ":" + restaurant.getName() + ":" + restaurant.getLocation() );
		
		Postcode postcode1 = addPostcode("SO17 1TJ");
		Postcode postcode2 = addPostcode("SO17 1BX");
		Postcode postcode3 = addPostcode("SO17 2NJ");
		Postcode postcode4 = addPostcode("SO17 1TW");
		Postcode postcode5 = addPostcode("SO17 2LB");
		
		Supplier supplier1 = addSupplier("Supplier 1",postcode1);
		Supplier supplier2 = addSupplier("Supplier 2",postcode2);
		Supplier supplier3 = addSupplier("Supplier 3",postcode3);
		 
		Ingredient ingredient1 = addIngredient("Ingredient 1","grams",supplier1,1,5,1);
		Ingredient ingredient2 = addIngredient("Ingredient 2","grams",supplier2,1,5,1);
		Ingredient ingredient3 = addIngredient("Ingredient 3","grams",supplier3,1,5,1);
		
		Dish dish1 = addDish("Dish 1","Dish 1",1,1,10);
		Dish dish2 = addDish("Dish 2","Dish 2",2,1,10);
		Dish dish3 = addDish("Dish 3","Dish 3",3,1,10);
		
		dish1.setRecipe(recipe);
		
		
		recipeforDish1.put(ingredient1, 1);
		recipeforDish1.put(ingredient2, 2);
		
		recipeforDish2.put(ingredient2, 3);
		recipeforDish2.put(ingredient3, 1);
		
		recipeforDish2.put(ingredient1, 2);
		recipeforDish2.put(ingredient3, 1);
		
		//orders.add(new Order(Map <Dish, Number> basket, ));
		
		addIngredientToDish(dish1,ingredient1,1);
		addIngredientToDish(dish1,ingredient2,2);
		addIngredientToDish(dish2,ingredient2,3);
		addIngredientToDish(dish2,ingredient3,1);
		addIngredientToDish(dish3,ingredient1,2);
		addIngredientToDish(dish3,ingredient3,1); 
		
		addStaff("Staff 1");
		addStaff("Staff 2");
		addStaff("Staff 3");
		
		addDrone(1);
		addDrone(2);
		addDrone(3);
	}
	
	@Override
	public List<Dish> getDishes() {
		//this.notifyUpdate();
		return this.dishes;
		
	}

	@Override
	public Dish addDish(String name, String description, Number price, Number restockThreshold, Number restockAmount) {
		Dish newDish = new Dish(name,description,price,restockThreshold,restockAmount);
		this.dishes.add(newDish);
		serverComms.sendMessage(new Message("DISHES_REFRESHMENT", dishes));
		DishesStock.addDish(newDish);
		System.out.println("About to run");
		newDish.setRecipe(recipeforDish1);
		DataPersistence.writeToFile("DISH" + ":" + newDish.getName() + ":" + newDish.getDescription() + ":" + newDish.getRestockAmount() + ":"  + newDish.getRestockThreshold() + ":" + newDish.getStock());
		if(newDish.getName().equals("Dish 1")) {
	            DataPersistence.writeToFile1(",1 * Ingredient 1,2 * Ingredient 2");
	    		
		}
		else if(newDish.getName().equals("Dish 2")) {
			DataPersistence.writeToFile1(",3 * Ingredient 2,1 * Ingredient 3");
			
		}
		else if(newDish.getName().equals("Dish 3")) {
			DataPersistence.writeToFile1(",2 * Ingredient 1,1 * Ingredient 3");
			
		}
		else {
			Map <Ingredient, Number> map = new HashMap<Ingredient, Number>();
			
			map = newDish.getRecipe();
			System.out.println("Here");
			System.out.println("size of recipe map "+map.size());
			for (Map.Entry<Ingredient, Number> entry: map.entrySet()){
				System.out.println("size of recipe map "+map.size());
				Ingredient ingredient = entry.getKey();
				System.out.println("ingredient: "+ingredient.getName());
	            Number value = entry.getValue();
	        	System.out.println("value: "+value);
	            DataPersistence.writeToFile1("," + value.toString() + " * " + ingredient.getName());
	            System.out.println(value.toString() + " * " + ingredient.getName());
			}
		}	
		
		this.notifyUpdate();
		return newDish;
	}
	
	@Override
	public void removeDish(Dish dish) {
		this.dishes.remove(dish);
		serverComms.sendMessage(new Message("DISHES_REFRESHMENT", dishes));
		this.notifyUpdate();
	}

	@Override
	public Map<Dish, Number> getDishStockLevels() {
		this.notifyUpdate();
		return levels;
	}
	
	@Override
	public void setRestockingIngredientsEnabled(boolean enabled) {
		
	}

	@Override
	public void setRestockingDishesEnabled(boolean enabled) {
		
	}
	
	@Override
	public void setStock(Dish dish, Number stock) {
		//System.out.println("setstock server" + dish.getName() + stock);
		dish.setStock(stock);
		levels.put(dish, stock);
		System.out.println("Server stock: "+ stock);
		if(! stock.equals(0) || ! stock.equals(null)) {
			DataPersistence.writeToFile("STOCK" + ":" + dish.getName() + ":" + stock);
		}
		this.notifyUpdate();
	}
	

	@Override
	public void setStock(Ingredient ingredient, Number stock) {
		ingredient.setStock(stock);
		levels1.put(ingredient, stock);
		if(! stock.equals(0) || ! stock.equals(null)) {
			DataPersistence.writeToFile("STOCK" + ":" + ingredient.getName() + ":" + stock);
		}
		this.notifyUpdate();
	}

	@Override
	public List<Ingredient> getIngredients() {
		return this.ingredients;
	}

	@Override
	public Ingredient addIngredient(String name, String unit, Supplier supplier,
		Number restockThreshold, Number restockAmount, Number weight) {
		Ingredient mockIngredient = new Ingredient(name,unit,supplier,restockThreshold,restockAmount,weight);
		this.ingredients.add(mockIngredient);
		serverComms.sendMessage(new Message("INGREDIENTS_REFRESHMENT", ingredients));
		IngredientsStock.addIngredient(mockIngredient);
		DataPersistence.writeToFile("INGREDIENT" + ":" + mockIngredient.getName() + ":" + mockIngredient.getUnit() + ":" + mockIngredient.getSupplier() + ":" + mockIngredient.getRestockAmount() + ":" + mockIngredient.getRestockThreshold() + ":" + mockIngredient.getRestockAmount());
		if(!(mockIngredient.getStock().equals(0))) {
			DataPersistence.writeToFile("STOCK" + ":" + mockIngredient.getName() + ":" + mockIngredient.getStock());
		}
		this.notifyUpdate();
		return mockIngredient;
	}
	
	@Override
	public void removeIngredient(Ingredient ingredient) {
		int index = this.ingredients.indexOf(ingredient);
		this.ingredients.remove(index);
		serverComms.sendMessage(new Message("INGREDIENTS_REFRESHMENT", ingredients));
		this.notifyUpdate();
	}

	@Override
	public List<Supplier> getSuppliers() {
		return this.suppliers;
	}

	@Override
	public Supplier addSupplier(String name, Postcode postcode) {
		Supplier mock = new Supplier(name,postcode);
		this.suppliers.add(mock);
		DataPersistence.writeToFile("SUPPLIER" + ":" + mock.getName() + ":" + mock.getPostcode());
		this.notifyUpdate();
		return mock;
	}


	@Override
	public void removeSupplier(Supplier supplier) {
		int index = this.suppliers.indexOf(supplier);
		this.suppliers.remove(index);
		this.notifyUpdate();
	}

	@Override
	public List<Drone> getDrones() {
		return this.drones;
	}

	@Override
	public Drone addDrone(Number speed) {
		Drone mock = new Drone(speed, droneLock);
		this.drones.add(mock);
		mock.setStatus("Idle");
		System.out.println("Added drone in server:" + mock.getName());
		DataPersistence.writeToFile("DRONE" + ":" + mock.getSpeed());
		this.notifyUpdate();
		return mock;
	}

	@Override
	public void removeDrone(Drone drone) {
		int index = this.drones.indexOf(drone);
		this.drones.remove(index);
		this.notifyUpdate();
	}
	
	@Override
	public List<Staff> getStaff() {
		return this.staff;
	}

	@Override
	public Staff addStaff(String name) {
		Staff mock = new Staff(name, this.staffLock);
		
		this.staff.add(mock);
		mock.setStatus("Idle");
		System.out.println("Added staff in server:" + mock.getName());
		
		DataPersistence.writeToFile("STAFF" + ":" + mock.getName());
		
		return mock;
	}

	@Override
	public void removeStaff(Staff staff) {
		this.staff.remove(staff);
		this.notifyUpdate();
	}

	@Override
	public List<Order> getOrders() {
		for(Order order: orders) {
			order.setStatus("Pending");
		}
		Drone.getOrders(orders);
		//System.out.println(orders);
		return this.orders;
	}

	@Override
	public void removeOrder(Order order) {
		int index = this.orders.indexOf(order);
		this.orders.remove(index);
		this.notifyUpdate();
	}
	
	@Override
	public Number getOrderCost(Order order) {
		Random random = new Random();
		return random.nextInt(100);
	}

	@Override
	public Map<Ingredient, Number> getIngredientStockLevels() {
		/*Random random = new Random();
		List<Ingredient> ingredients = getIngredients();
		//HashMap<Ingredient, Number> levels = new HashMap<Ingredient, Number>();
		for(Ingredient ingredient : ingredients) {
			levels1.put(ingredient,random.nextInt(50));
		} */
		for (Ingredient ingredient: levels1.keySet()){
            Number value = levels1.get(ingredient);  
            //System.out.println(ingredient.getName() + " " + value);  
		} 
		return levels1;
	}

	@Override
	public Number getSupplierDistance(Supplier supplier) {
		return supplier.getDistance();
	}

	@Override
	public Number getDroneSpeed(Drone drone) {
		return drone.getSpeed();
	}

	@Override
	public Number getOrderDistance(Order order) {
		Order mock = (Order)order;
		return mock.getDistance();
	}

	@Override
	public void addIngredientToDish(Dish dish, Ingredient ingredient, Number quantity) {
		if(quantity == Integer.valueOf(0)) {
			removeIngredientFromDish(dish,ingredient);
		} else {
			dish.getRecipe().put(ingredient,quantity);
		}
	}

	@Override
	public void removeIngredientFromDish(Dish dish, Ingredient ingredient) {
		dish.getRecipe().remove(ingredient);
		this.notifyUpdate();
	}

	@Override
	public Map<Ingredient, Number> getRecipe(Dish dish) {
		return dish.getRecipe();
	}

	@Override
	public List<Postcode> getPostcodes() {
		return this.postcodes;
	}

	@Override
	public Postcode addPostcode(String code) {
		Postcode mock = new Postcode(code, restaurant);
		//Postcode mock = new Postcode(code);
		this.postcodes.add(mock);
		serverComms.sendMessage(new Message("POSTCODES_REFRESHMENT", postcodes));
		DataPersistence.writeToFile("POSTCODE" + ":" + mock.getName());
		this.notifyUpdate();
		return mock;
	}

	@Override
	public void removePostcode(Postcode postcode) throws UnableToDeleteException {
		this.postcodes.remove(postcode);
		serverComms.sendMessage(new Message("POSTCODES_REFRESHMENT", postcodes));
		this.notifyUpdate();
	}

	@Override
	public List<User> getUsers() {
		return this.users;
	}
	
	@Override
	public void removeUser(User user) {
		this.users.remove(user);
		serverComms.sendMessage(new Message("USERS_REFRESHMENT", users));
		this.notifyUpdate();
	}
	
	@Override
	public void addUser(User user) {
		this.users.add(user);
		serverComms.sendMessage(new Message("USERS_REFRESHMENT", users));
		//orders.addAll(client.getOrders(user));
		this.notifyUpdate();
	}

	@Override
	public void loadConfiguration(String filename){
		System.out.println("Loaded configuration: " + filename);
			new Configuration(filename, this);
			this.notifyUpdate();
	}

	@Override
	public void setRecipe(Dish dish, Map<Ingredient, Number> recipe) {
		for(Entry<Ingredient, Number> recipeItem : recipe.entrySet()) {
			addIngredientToDish(dish,recipeItem.getKey(),recipeItem.getValue());
		}
		this.notifyUpdate();
	}

	@Override
	public boolean isOrderComplete(Order order) {
		return true;
	}

	@Override
	public String getOrderStatus(Order order) {
		Random rand = new Random();
		if(rand.nextBoolean()) {
			return "Complete";
		} else {
			return "Pending";
		}
	}
	
	@Override
	public String getDroneStatus(Drone drone) {
		Random rand = new Random();
		if(rand.nextBoolean()) {
			return "Idle";
		} else {
			return "Flying";
		}
	}
	
	@Override
	public String getStaffStatus(Staff staff) {
		Random rand = new Random();
		if(rand.nextBoolean()) {
			return "Idle";
		} else {
			return "Working";
		}
	}

	@Override
	public void setRestockLevels(Dish dish, Number restockThreshold, Number restockAmount) {
		dish.setRestockThreshold(restockThreshold);
		dish.setRestockAmount(restockAmount);
		this.notifyUpdate();
	}

	@Override
	public void setRestockLevels(Ingredient ingredient, Number restockThreshold, Number restockAmount) {
		ingredient.setRestockThreshold(restockThreshold);
		ingredient.setRestockAmount(restockAmount);
		this.notifyUpdate();
	}

	@Override
	public Number getRestockThreshold(Dish dish) {
		return dish.getRestockThreshold();
	}

	@Override
	public Number getRestockAmount(Dish dish) {
		return dish.getRestockAmount();
	}

	@Override
	public Number getRestockThreshold(Ingredient ingredient) {
		return ingredient.getRestockThreshold();
	}

	@Override
	public Number getRestockAmount(Ingredient ingredient) {
		return ingredient.getRestockAmount();
	}

	@Override
	public void addUpdateListener(UpdateListener listener) {
		this.listeners.add(listener);
	}
	
	@Override
	public void notifyUpdate() {
		this.listeners.forEach(listener -> listener.updated(new UpdateEvent()));
	}

	@Override
	public Postcode getDroneSource(Drone drone) {
		return drone.getSource();
	}

	@Override
	public Postcode getDroneDestination(Drone drone) {
		return drone.getDestination();
	}

	@Override
	public Number getDroneProgress(Drone drone) {
		return drone.getProgress();
	}

	@Override
	public String getRestaurantName() {
		return restaurant.getName();
	}

	@Override
	public Postcode getRestaurantPostcode() {
		return restaurant.getLocation();
	}
	
	@Override
	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void addOrder(Order object) {
		orders.add(object);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		object.setName(dtf.format(now));
		//Drone.addOrder(object);
		
	}


}

