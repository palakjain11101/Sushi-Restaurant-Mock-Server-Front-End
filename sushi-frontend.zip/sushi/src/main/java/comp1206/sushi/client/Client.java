package comp1206.sushi.client;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import comp1206.sushi.common.ClientComms;
import comp1206.sushi.common.DataPersistence;
import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Drone;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.common.Message;
import comp1206.sushi.common.Order;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.common.Restaurant;
import comp1206.sushi.common.Staff;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.common.UpdateEvent;
import comp1206.sushi.common.UpdateListener;
import comp1206.sushi.common.User;
import comp1206.sushi.server.Server;

public class Client implements ClientInterface {

	//DataPersistence2 data = new DataPersistence2();
    private static final Logger logger = LogManager.getLogger("Client");
    ClientComms clientComms;
    Server server;
    Number orderCost;
	public Restaurant restaurant;
	public List<Dish> dishes = new ArrayList<Dish>();
	public ArrayList<Drone> drones = new ArrayList<Drone>();
	public ArrayList<Ingredient> ingredients = new ArrayList<Ingredient>();
	public ArrayList<Order> orders = new ArrayList<Order>();
	public ArrayList<Staff> staff = new ArrayList<Staff>();
	public ArrayList<Supplier> suppliers = new ArrayList<Supplier>();
	public ArrayList<User> users = new ArrayList<User>();
	public ArrayList<Postcode> postcodes = new ArrayList<Postcode>();
	private ArrayList<UpdateListener> listeners = new ArrayList<UpdateListener>();
	Map<Dish, Number> basket = new HashMap<Dish, Number>();
	private boolean check = false;
	
	public Client() {
        logger.info("Starting up client...");
		clientComms= new ClientComms(this);
        Thread thread = new Thread(clientComms);
        thread.start();
        
		Postcode restaurantPostcode = new Postcode("SO17 1BJ");
		restaurant = new Restaurant("Mock Restaurant",restaurantPostcode);

	}
	
	@Override
	public Restaurant getRestaurant() {
		return restaurant;
	}
	

	
	@Override
	public String getRestaurantName() {
		return restaurant.getName();
	}
	
	@Override
	public Postcode getRestaurantPostcode() {
		return restaurant.getLocation();
	}
	
	@Override
	public User register(String username, String password, String address, Postcode postcode) {
		User user = new User(username, password, address, postcode);
		this.users.add(user);
		clientComms.sendMessage(new Message("NEW_USER", user));
		DataPersistence.writeToFile("USER" + ":" + user.getName() + ":" +user.getAddress() + ":" + "password:" + user.getPostcode());
		return user;
	}

	@Override
	public User login(String username, String password) {
		User registeredUser = null;
		for(User user: users) {
			if(user.getName().equals(username) && user.getPassword().equals(password)) {
				registeredUser = user;
				check = true;
			}
		}
		return registeredUser;
	}

	@Override
	public List<Postcode> getPostcodes() {
		return this.postcodes;
	}

	@Override
	public List<Dish> getDishes() {
		System.out.println(dishes);
		return this.dishes;
	}

	@Override
	public String getDishDescription(Dish dish) {
		return dish.getDescription();
	}

	@Override
	public Number getDishPrice(Dish dish) {
		return dish.getPrice();
	}

	@Override
	public Map<Dish, Number> getBasket(User user) {
		return basket;
	}

	@Override
	public Number getBasketCost(User user) {
		getBasket(user);
		int totalPrice = 0;
		for (Map.Entry<Dish, Number> entry : basket.entrySet()) {
		    Dish dish = entry.getKey();
		    int q = (int) entry.getValue();
		    int p = (int) dish.getPrice();
		    int totalForDish = q*p;
		    totalPrice = totalPrice + totalForDish;
		}
		return totalPrice;
	}

	@Override
	public void addDishToBasket(User user, Dish dish, Number quantity) {
			getBasket(user).put(dish,quantity);
	}

	@Override
	public void updateDishInBasket(User user, Dish dish, Number quantity) {
		getBasket(user).put(dish,quantity);
		getBasketCost(user);

	}

	@Override
	public Order checkoutBasket(User user) {
		Order order = new Order();
		order.setCost(getBasketCost(user));
		order.setName(user.getName());
		order.setStatus("Pending");
		
		orders.add(order);
		
		clientComms.sendMessage(new Message("NEW_ORDER", order));
		DataPersistence.writeToFile("ORDER" + ":" + user.getName() + ":");
		
		basket = new HashMap<Dish, Number>();
		basket = getBasket(user);
		System.out.println("Here");
		for (Map.Entry<Dish, Number> entry: basket.entrySet()){
			Dish dish = entry.getKey();
			System.out.println("dish: " + dish.getName());
            Number value = entry.getValue();
        	System.out.println("value: "+value);
            DataPersistence.writeToFile1("," + value.toString() + " * " + dish.getName());
            System.out.println(value.toString() + " * " + dish.getName());
		}
		
		clearBasket(user);
		
		DataPersistence.writeToFile1("5 * Dish 1,2 * Dish 2");
		return order;
	}

	@Override
	public void clearBasket(User user) {
		basket.clear();
	}

	@Override
	public List<Order> getOrders(User user) {
		return this.orders;
	}

	@Override
	public boolean isOrderComplete(Order order) {
		return true;
	}

		
	@Override
	public String getOrderStatus(Order order) {
		String status = order.getStatus();
		return status;
	}

	@Override
	public Number getOrderCost(Order order) {
		return orderCost;
	}

	@Override
	public void cancelOrder(Order order) {
		orders.remove(order);
	}

	@Override
	public void addUpdateListener(UpdateListener listener) {
		this.listeners.add(listener);
	}
	
	@Override
	public void notifyUpdate() {
		if(check) {
			this.listeners.forEach(listener -> listener.updated(new UpdateEvent()));
		}
	}

	public void setDishes(List<Dish> object) {
		
		this.dishes = object;
		this.notifyUpdate();
		
	}

	public void setUsers(ArrayList<User> object) {
		this.users = object;
		this.notifyUpdate();
		
	}

	public void setPostcodes(ArrayList<Postcode> object) {
		this.postcodes = object;
		this.notifyUpdate();
	}

	public void setOrders(ArrayList<Order> object) {
		this.orders = object;
		this.notifyUpdate();
	}


	
	/*public void setUser(Order order, User user) {
		
		
	} */
}
