package comp1206.sushi.common;

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import comp1206.sushi.client.Client;
import comp1206.sushi.server.Server;
 
public class ClientComms implements Runnable{
	private Client client;
	private BlockingQueue<Message> messageQueue = new LinkedBlockingQueue<>();
	
	public ClientComms(Client client) {
		this.client =client;
	}
	public void sendMessage(Message message) {
		try {
			messageQueue.put(message);
		}
		
		catch(InterruptedException e){
			e.printStackTrace();
		}
	}
	
	private void receiveMessage(Message message) {
		/*if(!message.getText().equals("No_SERVER_UPDATE")) {
			//System.out.println(message.getText());
		}*/
		
		switch(message.getText()) {
			case "DISHES_REFRESHMENT":
				List<Dish> dishes = ((List<Dish>) message.getObject());
				System.out.println(dishes);
				client.setDishes(dishes);
				break;
			
		
			case "USERS_REFRESHMENT":
				client.setUsers((ArrayList<User>) message.getObject());
				break;
			
			case "POSTCODES_REFRESHMENT":
				client.setPostcodes((ArrayList<Postcode>) message.getObject());
				break;
			
			case "ORDERS_REFRESHMENT":
				client.setOrders((ArrayList<Order>) message.getObject());
				break;
			}
	}
	@Override
	public void run() {
		try {
			Socket socket = new Socket(InetAddress.getLocalHost(), 1003);
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			
			Message messageToSend;
			
			while(true) {
				this.receiveMessage((Message) in.readObject());
				messageToSend = messageQueue.poll();
				if(messageToSend != null) {
					out.writeObject(messageToSend);
					out.reset();
				}else {
					messageToSend = new Message("NO_CLIENT_UPDATE", "no_update");
					out.writeObject(messageToSend);
				}
			}
		}
		catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}