package comp1206.sushi.common;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Random;

import comp1206.sushi.client.Client;
import comp1206.sushi.common.Order;
import comp1206.sushi.server.Server;

public class Order extends Model implements Serializable{

	private String status;
	Number cost;
	//Map <Dish, Number> basket;
	
	public Order() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		this.name = dtf.format(now);
	}

	public Number getDistance() {
		return 1;
	}

	@Override
	public String getName() {
		return this.name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		notifyUpdate("status",this.status,status);
		this.status = status;
	}
	
	public void setCost(Number cost) {
		this.cost = cost;
	}
	
	public Number getCost() {
		return this.cost;
	}
	


}