package comp1206.sushi.common;

import java.io.Serializable;

//must implement Serializable in order to be sent
public class Message implements Serializable{
 private final String text;
 private final Object object;

 public Message(String text, Object object) {
     this.text = text;
     this.object = object;
 }

 public String getText() {
     return text;
 }
 
 public Object getObject() {
     return object;
 }
}