package comp1206.sushi.common;

import java.io.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import comp1206.sushi.server.Server;
 
public class ServerComms implements Runnable

{
	private Server server;
	ExecutorService threadPool = Executors.newFixedThreadPool(350);
	private static Set<ClientHandler> clientHandlers = new HashSet<>();
	
	
	public ServerComms(Server server) {
		this.server = server;
	}
	
	public void sendMessage(Message message) {
		for(ClientHandler client: clientHandlers) {
			client.addToMessageQueue(message);
		}
	}

	@Override
	public void run() {
		System.out.println("Heyaaaaaaaaa");
		try(ServerSocket serverSocket = new ServerSocket(1003)){
			while(true) {
				ClientHandler clientHandler = new ClientHandler(serverSocket.accept(), server);
				threadPool.execute(clientHandler);
				clientHandlers.add(clientHandler);
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private static class ClientHandler implements Runnable{
		private Socket socket;
		private Server server;
		private ObjectInputStream in;
		private ObjectOutputStream out;
		private Queue<Message> messageQueue = new LinkedBlockingQueue<>();
		
		public ClientHandler(Socket socket, Server server) {
			this.socket = socket;
			this.server = server;
		}
		
		public void addToMessageQueue(Message message) {
			this.messageQueue.add(message);
		}
		
		private void receiveMessage(Message message) {
			switch(message.getText()) {
				case "NEW_USER":
					server.getUsers().add((User) message.getObject());
					break;
				case "NEW_ORDER":
					server.addOrder((Order) message.getObject());
					break;
				default:
					break;
			}
		}

		@Override
		public void run() {
			try {
				System.out.println("Client " + socket + "is connected");
				out = new ObjectOutputStream(socket.getOutputStream());
				out.writeObject(new Message("POSTCODES_REFRESHMENT", server.getPostcodes()));
				out.writeObject(new Message("USERS_REFRESHMENT", server.getUsers()));
				out.writeObject(new Message("DISHES_REFRESHMENT", server.getDishes()));
				out.writeObject(new Message("ORDERS_REFRESHMENT", server.getOrders()));
				
				in = new ObjectInputStream(socket.getInputStream());
				
				while(!socket.isClosed()) {
					Message messageToSend = messageQueue.poll();
					if(messageToSend != null) {
						out.writeObject(messageToSend);
						out.reset();
					}else {
						messageToSend = new Message("NO_SERVER_UPDATE", "no_update");
						out.writeObject(messageToSend);
					} 
					this.receiveMessage((Message) in.readObject());
				}
			}
			catch(IOException | ClassNotFoundException e) {
			}
			finally {
				try {
					clientHandlers.remove(this);
					socket.close();
					System.out.println("Connection closed: " +socket);
				}catch(IOException e) {
					e.printStackTrace();
				}
			}
			
		}
		
	}
	

	
}