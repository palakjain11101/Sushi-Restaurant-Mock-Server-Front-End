package comp1206.sushi.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.locks.Lock;

import comp1206.sushi.common.Staff;
import comp1206.sushi.server.DishesStock;
import comp1206.sushi.server.Server;

public class Staff extends Model implements Runnable, Serializable {
	Object lock;
	private String name;
	private String status;
	private Number fatigue;
	Server server;
	//List<Dish> dishes = new ArrayList<Dish>();
	
	public Staff(String name, Object lock) {
		this.setName(name);
		this.setFatigue(0);
		this.lock = lock;
		new Thread(this).start();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Number getFatigue() {
		return fatigue;
	}

	public void setFatigue(Number fatigue) {
		this.fatigue = fatigue;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		notifyUpdate("status",this.status,status);
		this.status = status;
	}
	

	@Override
	public void run() {
		setFatigue(0);
		while(true) {
			//returns checked dishes
			List <Dish> dishes = new ArrayList <Dish>();
			//static List <Dish> dishes = Collections.synchronizedList(new ArrayList <Dish>());
			dishes = DishesStock.checkRestock();
			if(!dishes.isEmpty()) {
				System.out.println("Here are my" + dishes);
				synchronized(this.lock) {
				
					for(Dish dish: dishes) {
						//server.getDishStockLevels();
						//System.out.println("Here we are: " + server.getDishStockLevels().get(dish));
						
						
							DishesStock.restockDish(dish);
							int addedStock = (int) DishesStock.findAddedStock();
							System.out.println("Added Stock"+ addedStock);
							for(int i= 0; i <= addedStock; i++) {
							
							monitorStockLevels(dish);
							
							
							
							
							
							
							
							
							
							
							
							
							
							}
					}
				}
			}
		
		}
	}
		
		
	public void checkIngredientStock(Dish dish, Ingredient ingredient, Number ingredientStockInRecipe){
			//int ingredientStock = (int) ingredient.getStock();
			int ingredientStock = 10;
			if(ingredientStock >= (int) ingredientStockInRecipe){
				System.out.println("Ingredient stock before:"+ ingredientStock);
				ingredientStock = ingredientStock - (int) ingredientStockInRecipe;
				System.out.println("Ingredient stock after:"+ ingredientStock);
				ingredient.setStock(ingredientStock);
				

			}
		
	}
	


	private void prepareNewDish(Dish dish) {

			int fatigue = (int) getFatigue();
			if(fatigue < 100) {
				while(fatigue < 100) {
					System.out.println("Staff " + getName() + "is preparing dish");
					setStatus("Working");
					int randomNumber = (int) (Math.random() * (60000 - 20000)) + 20000;
					try {
						Thread.sleep(randomNumber);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					int dishStock = (int) dish.getStock();
					dish.setStock(dishStock + 1);
					setStatus("Idle");
					
					System.out.println("Staff has prepared dish");
					fatigue = fatigue + 5;
					setFatigue(fatigue);
					System.out.println("The staff fatigue is" + fatigue);
				}
			}
			else {
				System.out.println("Taking a break");
				try {
					Thread.sleep(100000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				setFatigue(100);
			}
			
			
		
	}
	

	public void monitorStockLevels(Dish dish) {
					System.out.println("Hey, what's up ?");
					int stock = (int) dish.getStock();
					//if(stock < (int)dish.getRestockThreshold()) {
						System.out.println("The stock is" + stock);
						Map<Ingredient, Number> recipeMap = dish.getRecipe();
						
						for (Map.Entry<Ingredient, Number> entry : recipeMap.entrySet()) {
							Ingredient ingredient = entry.getKey();
							Number ingredientStockInRecipe = entry.getValue();
							
							System.out.println(dish.getName());
							System.out.println(ingredient.getName());
							System.out.println(ingredientStockInRecipe);
						    checkIngredientStock(dish, ingredient, ingredientStockInRecipe); 
						 }
						prepareNewDish(dish);
					//}
				

			
	}

}
