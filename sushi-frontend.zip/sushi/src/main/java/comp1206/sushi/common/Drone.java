package comp1206.sushi.common;

import java.io.BufferedReader;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import comp1206.sushi.common.Drone;
import comp1206.sushi.server.DishesStock;
import comp1206.sushi.server.IngredientsStock;

public class Drone extends Model implements Runnable, Serializable {

	private Number speed;
	private Number progress;
	private static DecimalFormat df = new DecimalFormat("0.00");
	private Number capacity;
	private Number battery;
	
	private String status;
	static List <Order> ordersList = new CopyOnWriteArrayList<Order>();
	//static ArrayList <Order> ordersList;
	private Postcode source;
	private Postcode destination;
	Object lock;
	boolean idle;
	boolean idle1;
	boolean idle2;

	public Drone(Number speed, Object lock) {
		this.setSpeed(speed);
		this.setCapacity(1);
		this.setBattery(100);
		this.lock = lock;
		new Thread(this).start();
	}

	public Number getSpeed() {
		return speed;
	}

	
	public Number getProgress() {
		return progress;
	}
	
	public void setProgress(Number progress) {
		this.progress = progress;
	}
	
	public void setSpeed(Number speed) {
		this.speed = speed;
	}
	
	@Override
	public String getName() {
		return "Drone (" + getSpeed() + " speed)";
	}

	public Postcode getSource() {
		return source;
	}

	public void setSource(Postcode source) {
		this.source = source;
	}

	public Postcode getDestination() {
		return destination;
	}

	public void setDestination(Postcode destination) {
		this.destination = destination;
	}

	public Number getCapacity() {
		return capacity;
	}

	public void setCapacity(Number capacity) {
		this.capacity = capacity;
	}

	public Number getBattery() {
		return battery;
	}

	public void setBattery(Number battery) {
		this.battery = battery;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		notifyUpdate("status",this.status,status);
		this.status = status;
	}


	@Override
	public void run() {
		boolean check;
		setCapacity(10);
		setBattery(100);
		while(true) {
			check = true;
			setProgress(0);
			if(check = true) {
				List <Ingredient> ingredients = new ArrayList <Ingredient>();
				ingredients = IngredientsStock.checkRestock();
				
				synchronized(this.lock) {
					
					if(!ingredients.isEmpty()) {
						System.out.println("Here are my" + ingredients);
						
							for(Ingredient ingredient: ingredients) {
									int weight = (int) ingredient.getWeight();
									
									IngredientsStock.restockIngredient(ingredient);
									int addedStock = (int) IngredientsStock.findAddedStock();
									System.out.println("Added Stock"+ addedStock);
									int totalWeight = weight * addedStock;
									System.out.println("The total weight of this ingredient is:" + totalWeight);
									int capacity = (int) getCapacity();
									if(totalWeight < capacity) {
										System.out.println("The total weight of the ingredients is lower than the capacity of the drone");
										monitorStockLevels(ingredient, addedStock);
									}
									else {
										System.out.println("The weight of the ingredients exceeds the capacity of the drone");
									}
									
							}
						
					}
					else{
						if(!ordersList.isEmpty()) {
							System.out.println("Here are my" + ordersList);
							System.out.println(ordersList.size() + " --> size of ordersList");
							Iterator<Order> i = ordersList.iterator();
							while(i.hasNext()) {
								Order order = i.next();
								monitorOrders(order);
								
								//removeOrder(order);
								i.remove();
							}
						}	

						
					}
					check = false;
			}
		}

	}
		
		
	}


	/*private void removeOrder(Order order) {
		ordersList.remove(order);
		
	} */

	private void monitorOrders(Order order) {
				 if(order.getStatus().equals("Pending")) {
						System.out.println("Drone " + getName() + "is delivering order" + order.getName());
						double distance = order.getDistance().doubleValue();
						
						double speed = (int) getSpeed();
						double time = (distance *2 )/speed;
						
						System.out.println("The distance is " + distance);
						System.out.println("The speed is" + speed);
						System.out.println("The time taken is " + time);
						
						setStatus("Flying");
						
						if(getStatus().equals("Flying")) {
							for(int i = 0; i <= time; i++) {
								double progress = heyDroneProgress(time,i);
								System.out.println("The progress is" + progress);
							}
						}
						
						order.setStatus("Complete");
						setStatus("Idle");
						System.out.println("Drone has delivered order and returned to restaurant");
						//ordersList.remove(order);
						
				 }
			 
		
	}
	
	private Double heyDroneProgress(Double time, int i) {
		
				try {
					int battery = (int)getBattery();
					if(battery > 0) {
						while(battery > 0) {
							//long start = System.currentTimeMillis();
							Thread.sleep(1000);
							setProgress(Double.valueOf(df.format((i/time)*100)));
							Double progress = (Double) getProgress();
							
							
							setBattery(battery - 1);
							System.out.println("Drone battery is" + battery);
							
							return progress;
						}
					}
					else {
						System.out.println("Returning to base");
						Thread.sleep(100000);
						setBattery(100);
					}
					
					
						
				} catch (InterruptedException e) {
						e.printStackTrace();
				}
				
		
		return null;
		
	}

	public static void getOrders(List<Order> orders){
		ordersList = new ArrayList<Order>(orders);
	}

	private void getIngredients(Ingredient ingredient, int addedStock) {
			System.out.println("Drone " + getName() + "is leaving to collect ingredient from supplier");
			Supplier supplier = ingredient.getSupplier();
			double distance = supplier.getPostcode().getDistance().doubleValue();
			double longitude = supplier.getPostcode().getLongitude();
			
			double speed = (int) getSpeed();
			double time = (distance * 2 * 10)/speed;
			
			System.out.println("The distance is " + distance);
			System.out.println("The speed is" + speed);
			System.out.println("The time taken is " + time);
			System.out.println("The longitude is " + longitude);
			
			setStatus("Flying");
			
			
			if(getStatus().equals("Flying")) {
				for(int i = 0; i <= time; i++) {
					double progress = heyDroneProgress(time,i);
					System.out.println("The progress is" + progress);
					
				}
			}
			
			int ingredientStock = (int) ingredient.getStock();
			ingredient.setStock(ingredientStock + addedStock);
			setStatus("Idle");
			System.out.println("Drone has collected ingredient from supplier");
		
	}
	

	public void monitorStockLevels(Ingredient ingredient, int addedStock) {
					//System.out.println("Hey, what's up ?");
					int stock = (int) ingredient.getStock();
					System.out.println("The stock is" + stock);
					if(addedStock > 0) {
						getIngredients(ingredient, addedStock);
					}
		
	}
	

	
	
}
