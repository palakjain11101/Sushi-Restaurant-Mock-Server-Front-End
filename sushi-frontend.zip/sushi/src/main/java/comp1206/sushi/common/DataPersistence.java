package comp1206.sushi.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import comp1206.sushi.server.Configuration;
import comp1206.sushi.server.Server;

public class DataPersistence {
	
	static String notFile;
	private static BufferedWriter writer;
	
	static Server server;
	
	public DataPersistence(){
		notFile = "newserver.txt";
		try {
			    
			    writer = new BufferedWriter(new FileWriter(notFile));
			    writer.write("");
		}
		catch(Exception e) {
			
		}
	}
	

	public static void writeToFile(String string){
		try {
			    writer = new BufferedWriter(new FileWriter("newserver.txt", true));
			    writer.append(' ');
			    System.out.println("about to write string "+string);
			    writer.newLine();
			    writer.append(string);
			    writer.close();
		}
		catch(Exception e) {
			
		}
	}
	
	public static void writeToFile1(String string){
		try {
			    writer = new BufferedWriter(new FileWriter("newserver.txt", true));
			    System.out.println("about to write string "+string);
			    writer.append(string);
			    writer.close();
		}
		catch(Exception e) {
			
		}		
			
	}
	
	public static void createFile(){
		try {
		    writer = new BufferedWriter(new FileWriter("newserver.txt", false));
		}
		catch(Exception e) {
		
		}
	}
	
	public static void readFile() {
		
		server.loadConfiguration("newserver.txt");
		  
		/*BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("newserver.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		  
		String st; 
		try {
			while ((st = br.readLine()) != null) {
				server.loadConfiguration("newserver.txt");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} */
	}
	
	public static void loadServer(Server server1) {
		server = server1;
	}


}
